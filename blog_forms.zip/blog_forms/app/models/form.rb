class Form < ApplicationRecord
end
