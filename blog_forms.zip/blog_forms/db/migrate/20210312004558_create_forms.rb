class CreateForms < ActiveRecord::Migration[6.1]
  def change
    create_table :forms do |t|
      t.string :firstname
      t.string :lastname
      t.string :fathername
      t.string :email
      t.text :content

      t.timestamps
    end
  end
end
