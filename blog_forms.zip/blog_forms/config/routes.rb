Rails.application.routes.draw do
	root "forms#index"
	  # get "/forms", to: "forms#index"
	  resources :forms
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
end
